# AccessConfig
Configuration options for a better accessibility on the Web.
Let the user choose a contrast level, font, line spacing and justification to use. The script load a cookie in the user browser.

##Installation
In the `head` element, call the script `AccessConfig.js` : 

    <script src="js/AccessConfig.js" type="text/javascript"></script>	

In the `body`, add a button to open access config modal :  

	<button type="button" id="modal-button-c">Accessibilité</button>

Copy the fonts folder and add @font-face rules in your CSS

`
@font-face {
  font-family: 'opendys';
  src: url('fonts/opendyslexic-regular-webfont.eot');
  src: url('fonts/opendyslexic-regular-webfont.eot?#iefix') format('embedded-opentype'),
       url('fonts/opendyslexic-regular-webfont.woff2') format('woff2'),
       url('fonts/opendyslexic-regular-webfont.woff') format('woff'),
       url('fonts/opendyslexic-regular-webfont.ttf') format('truetype'),
       url('fonts/opendyslexic-regular-webfont.svg#opendyslexicregular') format('svg');
  font-weight: normal;
  font-style: normal;
}	
`
##How it works
The script just add a class to the `body` tag when user click a radio button
Exemple when a user click on `Contrastes inversés` : 

    <body class="inv-c">

Then, you just have to define properties for this class in css, below a generic class :
`
/* adaptive style */
	/* dyslexia font */
	body.dys-f{
		font-family:'opendys';
	}
	/* inverted contrast */
	.inv-c,
	.inv-c *{
		background:#000080;
		color:#FFFF00;
	}
	/* enforced contrats */
	.high-c,
	.high-c *{
		background:black;
		color:white;
	}
	/* dyslexia line-spacing */
	.dys-line-spacing,
	.dys-line-spacing *{
		line-height:1.5em;
	}
	/* dyslexia justification */
	.dys-justification,
	.dys-justification *{
		text-align:left;
	}
`